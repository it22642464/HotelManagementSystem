import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';

function FeedbackView() {
    const { id } = useParams();
    const navigate = useNavigate();
    const [feedback, setFeedback] = useState(null);
    const [loading, setLoading] = useState(true);
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        duration: '',
        howDidYouHear: '',
        quality: '',
        cleanliness: '',
        food: '',
        staff: '',
        suggestions: ''
    });

    useEffect(() => {
        const fetchFeedback = async () => {
            try {
                console.log('ID:', id); // Log the id parameter
                if (!id) {
                    throw new Error('ID parameter is missing');
                }
                const response = await axios.get(`http://localhost:8070/feedback/get/${id}`);
                setFeedback(response.data);
                setFormData(response.data); 
            } catch (error) {
                console.error("Error fetching feedback:", error);
            } finally {
                setLoading(false);
            }
        };
        fetchFeedback();
    }, [id]);
    

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async () => {
        try {
            navigate(`/feedback/update/${id}`); 
        } catch (error) {
            console.error("Error updating feedback:", error);
        }
    };

    const handleDeleteFeedback = async () => {
        try {
            await axios.delete(`http://localhost:8070/feedback/delete/${id}`);
            
            navigate('/');
        } catch (error) {
            console.error("Error deleting feedback:", error);
        }
    };

    if (loading) {
        return <div>Loading...</div>;
    }

    if (!feedback) {
        return <div>No feedback found.</div>;
    }

    return (
        
        <div>
            <h2>Feedback Details</h2>
            <p>Name: {feedback.name}</p>
            <p>Email: {feedback.email}</p>
            <p>Duration of Stay: {feedback.duration}</p>
            <p>How Did You Hear About Our Hotel: {feedback.howDidYouHear}</p>
            <p>Quality Rating: {feedback.quality}</p>
            <p>Cleanliness Rating: {feedback.cleanliness}</p>
            <p>Food Rating: {feedback.food}</p>
            <p>Staff Rating: {feedback.staff}</p>
            <p>Suggestions: {feedback.suggestions}</p>
            <button onClick={handleSubmit}>Update Feedback</button>
            <button onClick={handleDeleteFeedback}>Delete Feedback</button>
        </div>
       
    );
}

export default FeedbackView;
